const LoyaltyManager = () => {
    return (
      <div>
        <h2 className="text-2xl font-bold text-red-600 mb-4">📦 Quản lý Điểm</h2>
        <p>Đây là trang quản lý Điểm.</p>
      </div>
    );
  };
  
  export default LoyaltyManager;
  