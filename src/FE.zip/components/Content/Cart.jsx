import React, { useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { removeFromCart, updateQuantity, clearCart } from "../Redux/cartSlice";
import CholimexLayout from "../Layout/CholimexLayout";
import axios from "axios";

const Cart = () => {
  const cartItems = useSelector((state) => state.cart.cartItems);
  const dispatch = useDispatch();

  const [voucherCode, setVoucherCode] = useState("");
  const [discount, setDiscount] = useState(0);
  const [error, setError] = useState("");

  const handleQuantityChange = (id, newQty, maxQty) => {
    const value = parseInt(newQty);
    if (value < 1) return;
    if (value > maxQty) {
      alert("Số lượng vượt quá số lượng trong kho.");
      return;
    }
    dispatch(updateQuantity({ id, quantity: value }));
  };

  const totalPrice = cartItems.reduce(
    (acc, item) => acc + item.price * item.quantity,
    0
  );
  const discountedTotal = totalPrice * (1 - discount / 100);

  const applyVoucher = async () => {
    try {
      const res = await axios.get(`http://localhost:8080/api/voucher/${voucherCode}`);
      const data = res.data;
      if (data?.discountPercentage) {
        setDiscount(data.discountPercentage);
        setError("");
      } else {
        setError("Mã giảm giá không hợp lệ.");
        setDiscount(0);
      }
    } catch {
      setError("Không tìm thấy mã giảm giá.");
      setDiscount(0);
    }

    console.log(cartItems)
  };

  return (
    <CholimexLayout>
      <div className="bg-gradient-to-br from-red-600 to-red-700 py-10 px-2 sm:px-4 min-h-[60vh]">
        <div className="max-w-6xl mx-auto bg-white p-4 md:p-6 rounded-xl shadow-xl overflow-x-auto">
          <h2 className="text-xl sm:text-2xl font-bold text-center mb-6">🛒 Giỏ Hàng</h2>

          {cartItems.length === 0 ? (
            <p className="text-center">Giỏ hàng đang trống.</p>
          ) : (
            <>
              <div className="overflow-x-auto rounded-xl border border-gray-100 shadow-sm">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50 text-gray-700 uppercase text-xs tracking-wide">
                    <tr>
                      <th className="text-center px-4 py-3">Sản phẩm</th>
                      <th className="text-center px-4 py-3">Đơn giá</th>
                      <th className="text-center px-4 py-3">Số lượng</th>
                      <th className="text-center px-4 py-3">Tổng</th>
                      <th className="text-center px-4 py-3"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {cartItems.map((item) => (
                      <tr key={item.id} className="hover:bg-gray-50 transition border-t border-gray-100">
                        <td className="flex items-start gap-3 px-4 py-3 min-w-[200px]">
                          <img src={item.image} alt={item.name} className="w-24 h-24 object-cover rounded shadow" />
                          <div className="flex flex-col">
                            <span className="font-medium text-gray-800 line-clamp-1">{item.name}</span>
                            <span className="text-xs text-gray-500 mt-1">Kho: {item.stockQuantity}</span>
                          </div>
                        </td>
                        <td className="text-center px-4 py-3 text-gray-700">
                          ₫{item.price.toLocaleString()}
                        </td>
                        <td className="text-center px-4 py-3">
                          <input
                            type="number"
                            value={item.quantity}
                            min={1}
                            max={item.stockQuantity}
                            onChange={(e) => handleQuantityChange(item.id, e.target.value, item.stockQuantity)}
                            className="w-16 text-center border border-gray-300 rounded px-2 py-1"
                          />
                        </td>
                        <td className="text-center px-4 py-3 font-semibold text-gray-800">
                          ₫{(item.price * item.quantity).toLocaleString()}
                        </td>
                        <td className="text-center px-4 py-3">
                          <button
                            onClick={() => dispatch(removeFromCart(item.id))}
                            className="text-red-500 hover:underline text-sm"
                          >
                            Xóa
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Tổng tiền sau bảng */}
              <div className="mt-4 flex justify-end">
                <p className="text-base sm:text-lg font-semibold text-black">
                  Tổng tiền:&nbsp;
                  <span className="font-bold">₫{discountedTotal.toLocaleString()}</span>
                  {discount > 0 && (
                    <span className="text-xs text-gray-700 ml-2">(Đã giảm {discount}%)</span>
                  )}
                </p>
              </div>

              {/* Mã giảm giá */}
              <div className="flex flex-col md:flex-row items-center justify-between gap-4 mt-6">
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    placeholder="Nhập mã giảm giá"
                    value={voucherCode}
                    onChange={(e) => setVoucherCode(e.target.value)}
                    className="border px-3 py-1 rounded"
                  />
                  <button
                    onClick={applyVoucher}
                    className="bg-[#dd3333] text-white px-4 py-1.5 rounded hover:bg-red-600 transition"
                  >
                    Áp dụng
                  </button>
                </div>
                {error && <p className="text-red-600 text-sm">{error}</p>}
              </div>

              {/* Nút thao tác */}
              <div className="flex justify-end gap-2 mt-4">
                <button
                  onClick={() => dispatch(clearCart())}
                  className="bg-white text-red-600 px-4 py-2 rounded hover:bg-gray-100"
                >
                  Xóa toàn bộ
                </button>
                <button className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
                  Thanh toán
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </CholimexLayout>
  );
};

export default Cart;
