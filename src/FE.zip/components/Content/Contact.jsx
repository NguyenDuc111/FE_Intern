import CholimexLayout from "../Layout/CholimexLayout";




function Contact (){
    return (
        <>
        <CholimexLayout>
        <div>aaaaaaaaaa</div>
        </CholimexLayout>
        </>
    )
}

export default Contact;